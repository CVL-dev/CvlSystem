EMAP help

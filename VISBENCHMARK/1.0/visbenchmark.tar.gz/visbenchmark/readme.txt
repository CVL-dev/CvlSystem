Non-GPU visualisation performance test  
